/* */

#include <unistd.h>
#include <stdio.h>
// #include <sys/types.h>
// #include <sys/socket.h>
// #include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>

#include "Common.h"


int
main(int argc, char * argv[])
{
  int my_fd = get_socket();

  int rc = bind_socket(my_fd);

  rc = listen_on_socket(my_fd);

  int client_fd = accept_on_socket(my_fd);

  while (1) {
    char * str = get_msg_from_socket(client_fd);
    if (str) {
      fprintf(stderr, "%s\n", str);
    }
    // close(my_fd);
    // close(client_fd);
    // break;
  }

  return (0);
}


