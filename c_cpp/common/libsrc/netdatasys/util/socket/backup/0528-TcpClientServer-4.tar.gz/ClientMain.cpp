/* */

#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>

#include "Common.h"


int my_fd = 0;

void
signal_handler(int sig_no)
{
  fprintf(stderr, "\nsignal_handler() called for signal %d\n", sig_no);
  close(my_fd);
  my_fd = 0;
  exit(0);
}

void
setup_signal_handlers(void)
{
  struct sigaction act;
  memset(&act, 0, sizeof(act));

  sigemptyset(&act.sa_mask);
  act.sa_handler = signal_handler;
  sigaction(SIGINT, &act, NULL);
}

int
main(int argc, char * argv[])
{
  setup_signal_handlers();

  struct sockaddr_in server_addr;
  init_socket_addr(server_addr, NULL, 1);

  my_fd = get_socket();

  int rc = bind_socket(my_fd, SERVER_HOST, 0);

  // This is UDP
  // int rc = connect_to_socket(my_fd);

  char buffer[64];

  int loop = 1;

  while (1) {

    sprintf(buffer, "%d", loop++);
    
    int rc = send_msg_to_socket(my_fd, buffer, server_addr);

    fprintf(stderr, "send msg: %s\n", buffer);

    sleep(2);

  } // while (1)

  return (0);
}


