/* */

#include <unistd.h>
#include <stdio.h>
// #include <sys/types.h>
// #include <sys/socket.h>
// #include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <string.h>

#include "Common.h"

int
get_socket(void)
{
  int socket_fd = socket(AF_INET, SOCK_STREAM, 0);
  if (socket_fd < 0) {
    perror("socket() failed");
    exit(-1);
  }

#if 1

  int val = 1;

  int rc = setsockopt(socket_fd, IPPROTO_TCP, TCP_NODELAY, (char *) &val, sizeof(val));
  if (rc < 0) {
    perror("setsockopt() failed for TCP_NODELAY");
  }

  rc = setsockopt(socket_fd, SOL_SOCKET, SO_KEEPALIVE, (char *) &val, sizeof(val));
  if (rc < 0) {
    perror("setsockopt() failed for SO_KEEPALIVE");
  }

#endif

  return (socket_fd);
}

void
init_socket_addr(struct sockaddr_in & server_addr, const char * host_name)
{
  memset(&server_addr, 0, sizeof(server_addr));
  server_addr.sin_family      = AF_INET;

#if 0

  if (!host_name) {
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  } else {
    server_addr.sin_addr.s_addr = inet_addr(host_name);
  }

#else

  server_addr.sin_addr.s_addr = htonl(INADDR_ANY);

#endif

  server_addr.sin_port        = htons(SERVER_PORT);
}


int
bind_socket(int socket_fd)
{
  struct sockaddr_in server_addr;
  init_socket_addr(server_addr);

  int rc = bind(socket_fd, (struct sockaddr *) &server_addr, sizeof(server_addr));
  if (rc < 0) {
    perror("bind() failed");
    exit(-1);
  }

  return (rc);
}

int
listen_on_socket(int socket_fd)
{
  int rc = listen(socket_fd, 5);

  if (rc < 0) {
    perror("listen() failed");
    exit(-1);
  }

  return (rc);
}

int
accept_on_socket(int socket_fd)
{
  int clnt_len;
  struct sockaddr_in clnt_addr;

  int clnt_fd = accept(socket_fd, (struct sockaddr *) &clnt_addr, &clnt_len);

  if (clnt_fd < 0) {
    perror("accept() failed");
    exit(-1);
  }

  return (clnt_fd);
}

int
connect_to_socket(int socket_fd)
{
  struct sockaddr_in server_addr;
  init_socket_addr(server_addr, SERVER_HOST);
  int rc = connect(socket_fd, (struct sockaddr *) &server_addr, sizeof(server_addr));
  if (rc < 0) {
    perror("accept() failed");
    exit(-1);
  }
}

int
send_msg_to_socket(int socket_fd, const char * msg)
{
  int rc = 0;

  int len;

  rc = write(socket_fd, msg, (len=strlen(msg)+1));

  if (rc < 0) {
    perror("write() failed");
  }

  return (rc);
}

char *
get_msg_from_socket(int socket_fd)
{
  const int max_len = 64;

  static char ret[max_len];

  int rc = read(socket_fd, ret, max_len);

  if (rc < 0) {
    perror("read() failed");
    exit(-1);
  }

  return (ret);
}


