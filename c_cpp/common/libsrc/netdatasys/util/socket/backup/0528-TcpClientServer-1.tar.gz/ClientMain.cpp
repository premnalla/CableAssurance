
#include <unistd.h>
#include <stdio.h>

#include "Common.h"

int
main(int argc, char * argv[])
{
  int my_fd = get_socket();

  int rc = connect_to_socket(my_fd);

  char buffer[64];

  int loop = 1;

  while (1) {

    sprintf(buffer, "%d", loop++);
    
    int rc = send_msg_to_socket(my_fd, buffer);

    sleep(3);

    // close(my_fd);

    // break;
  }

  return (0);
}


