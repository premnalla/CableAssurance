/* */

#include <unistd.h>
#include <stdio.h>
// #include <sys/types.h>
// #include <sys/socket.h>
// #include <netinet/in.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <string.h>

#include "Common.h"


static const int MAX_FDS = 100;
int fd_array[MAX_FDS];

static void 
set_fd(int fd)
{
  for (int i=0; i<MAX_FDS; i++) {
    if (!fd_array[i]) {
      fd_array[i] = fd;
      break;
    }
  }
}

static void
clear_fd(int fd)
{
  for (int i=0; i<MAX_FDS; i++) {
    if (fd_array[i] == fd) {
      fd_array[i] = 0;
      break;
    }
  }
}

int
main(int argc, char * argv[])
{
  memset(fd_array, 0, sizeof(fd_array));

  int my_fd = get_socket();

  int rc = bind_socket(my_fd);

  rc = listen_on_socket(my_fd);

#if 0

  int client_fd = accept_on_socket(my_fd);

  while (1) {
    char * str = get_msg_from_socket(client_fd);
    if (str) {
      fprintf(stderr, "%s\n", str);
    }
    // close(my_fd);
    // close(client_fd);
    // break;
  }

#else

  fd_set my_read_fdset;
  FD_ZERO(&my_read_fdset);
  FD_SET(my_fd, &my_read_fdset);

  fd_set my_error_fdset;
  FD_ZERO(&my_error_fdset);

  struct timeval my_timeout;
  memset(&my_timeout, 0, sizeof(my_timeout));
  my_timeout.tv_sec = 1;

  int num_set_fds = 1;

  while (1) {

    int num_ready_fds = select(num_set_fds, &my_read_fdset, NULL, &my_error_fdset, &my_timeout);

    if (num_ready_fds < 0) {
      perror("select() failed\n");
      exit(-1);
    }

    if (FD_ISSET(my_fd, &my_read_fdset)) {
      int client_fd = accept_on_socket(my_fd);
      FD_SET(client_fd, &my_read_fdset);
      set_fd(client_fd);
    }

    for (int i=0; i<MAX_FDS; i++) {
      if (FD_ISSET(fd_array[i], &my_read_fdset)) {
        char * str = get_msg_from_socket(fd_array[i]);
        if (str) {
          fprintf(stderr, "%s\n", str);
        }
      }
    }

    for (int i=0; i<MAX_FDS; i++) {
      if (FD_ISSET(fd_array[i], &my_error_fdset)) {
        clear_fd(fd_array[i]);
      }
    }

  } // while (1)

#endif

  return (0);
}


