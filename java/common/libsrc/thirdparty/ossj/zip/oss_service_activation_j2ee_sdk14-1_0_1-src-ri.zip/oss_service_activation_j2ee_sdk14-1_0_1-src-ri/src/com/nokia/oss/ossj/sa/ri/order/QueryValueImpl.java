package com.nokia.oss.ossj.sa.ri.order;

import javax.oss.QueryValue;

import com.nokia.oss.ossj.common.ri.AttributeAccessImpl;

/**
 * @author aebbert
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public abstract class QueryValueImpl
	extends AttributeAccessImpl
	implements QueryValue {

    public Object clone() {
        return null;
    }
}
