package ossj.ttri;

/**
 * TTIteratorException Class
 *
 * @author Copyright 2002 MetaSolv Software, Inc. All rights reserved.
 * @version 1.0
 * @since February 2002
 */

public class TTIteratorException extends Exception {

    public TTIteratorException(String message) {
        super(message);
    }

}
