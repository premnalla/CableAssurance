/*
Copyright 2002-2005 The Members of the OSS through Java(TM) Initiative.
All rights reserved. Use is subject to license terms.
*/

package ossj.common.ex;

/**
 *
 * @author vince
 */
public interface ManagedEntityEx1Key extends ManagedEntityExKey {
    
}
