
package com.nokia.oss.ossj.common.ri.ex;

import javax.oss.*;
import com.nokia.oss.ossj.common.ri.*;


public interface ManagedEntityExKeyResult extends javax.oss.ManagedEntityKeyResult {

    public ManagedEntityExKey getManagedEntityExKey();
    
}


