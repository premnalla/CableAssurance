
package com.nokia.oss.ossj.common.ri.ex;

import javax.oss.ManagedEntityKey;

public interface ManagedEntityExKey extends javax.oss.ManagedEntityKey  
{
    
    
    
} 

